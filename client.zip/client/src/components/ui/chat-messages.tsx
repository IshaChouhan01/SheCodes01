import { useEffect, useRef } from "react";
import { Bot, User } from "lucide-react";

export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

interface ChatMessagesProps {
  messages: Message[];
  isTyping: boolean;
}

export function ChatMessages({ messages, isTyping }: ChatMessagesProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4" style={{ maxHeight: 'calc(100vh - 240px)' }}>
      {/* Welcome Message */}
      <div className="flex items-start space-x-3">
        <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
          <Bot className="text-white" size={16} />
        </div>
        <div className="bg-gray-100 rounded-lg rounded-tl-none p-3 max-w-md">
          <div 
            className="text-gray-800"
            dangerouslySetInnerHTML={{
              __html: "Welcome to SATI College! 🎓 I'm here to help you with information about our college, departments, faculty, admissions, and facilities. What would you like to know?"
            }}
          />
          <span className="text-xs text-gray-500 mt-1 block">Just now</span>
        </div>
      </div>

      {/* Chat Messages */}
      {messages.map((message) => (
        <div
          key={message.id}
          className={`flex items-start space-x-3 ${message.sender === 'user' ? 'justify-end' : ''}`}
        >
          {message.sender === 'user' ? (
            <>
              <div className="bg-blue-500 text-white rounded-lg rounded-tr-none p-3 max-w-md">
                <p>{message.content}</p>
                <span className="text-xs text-blue-200 mt-1 block">
                  {formatTime(message.timestamp)}
                </span>
              </div>
              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <User className="text-gray-600" size={16} />
              </div>
            </>
          ) : (
            <>
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                <Bot className="text-white" size={16} />
              </div>
              <div className="bg-gray-100 rounded-lg rounded-tl-none p-3 max-w-md">
                <div 
                  className="text-gray-800"
                  dangerouslySetInnerHTML={{ __html: message.content }}
                />
                <span className="text-xs text-gray-500 mt-1 block">
                  {formatTime(message.timestamp)}
                </span>
              </div>
            </>
          )}
        </div>
      ))}

      {/* Typing Indicator */}
      {isTyping && (
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
            <Bot className="text-white" size={16} />
          </div>
          <div className="bg-gray-100 rounded-lg rounded-tl-none p-3">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce-dot"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce-dot"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce-dot"></div>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
}
