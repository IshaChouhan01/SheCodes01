import { Building, ClipboardList, University, Users, Phone, BedDouble, PartyPopper, School } from "lucide-react";

interface QuickActionsProps {
  onQuickAction: (action: string) => void;
}

export function QuickActions({ onQuickAction }: QuickActionsProps) {
  const quickActions = [
    { id: 'departments', label: 'Departments', icon: Building },
    { id: 'admissions', label: 'Admissions', icon: ClipboardList },
    { id: 'facilities', label: 'Facilities', icon: University },
    { id: 'faculty', label: 'Faculty', icon: Users },
    { id: 'contact', label: 'Contact', icon: Phone },
    { id: 'hostel', label: 'Hostel', icon: BedDouble },
    { id: 'campusLife', label: 'Campus Life', icon: School },
    { id: 'events', label: 'Events', icon: PartyPopper },
  ];

  return (
    <div className="bg-gray-50 p-4 border-b">
      <p className="text-sm text-gray-600 mb-3 font-medium">Quick Information:</p>
      <div className="flex flex-wrap gap-2">
        {quickActions.map((action) => {
          const IconComponent = action.icon;
          return (
            <button
              key={action.id}
              onClick={() => onQuickAction(action.id)}
              className="bg-white border border-gray-200 rounded-full px-4 py-2 text-sm hover:bg-blue-50 hover:border-blue-300 transition-colors flex items-center space-x-2"
            >
              <IconComponent size={16} className="text-blue-700" />
              <span>{action.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

