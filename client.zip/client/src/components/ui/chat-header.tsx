import { GraduationCap, Info } from "lucide-react";

export function ChatHeader() {
  return (
    <header className="bg-blue-700 text-white p-4 flex items-center space-x-4 shadow-lg">
      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
        <GraduationCap className="text-blue-700 text-xl" size={24} />
      </div>
      <div className="flex-1">
        <h1 className="text-lg font-semibold">SATI College Assistant</h1>
        <p className="text-blue-200 text-sm flex items-center">
          <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
          Online - Ready to help
        </p>
      </div>
      <button className="text-white hover:text-blue-200 transition-colors">
        <Info size={20} />
      </button>
    </header>
  );
}
