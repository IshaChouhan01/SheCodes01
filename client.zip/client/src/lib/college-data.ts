export interface Department {
  name: string;
  programs: string[];
  faculty: string;
  specializations: string[];
  labs: string[];
}

export interface CollegeData {
  basic: {
    name: string;
    location: string;
    established: string;
    affiliation: string;
    type: string;
  };
  departments: Record<string, Department>;
  admissions: {
    eligibility: string;
    process: string;
    seats: string;
    fees: string;
    documents: string[];
  };
  facilities: string[];
  contact: {
    address: string;
    phone: string;
    email: string;
    website: string;
  };
  hostels:{
    main:string;
    why:string;
  }
  campusLife: {
    main: string;
    why: string;
  };
  alumni: {
    main: string;
    why: string;
  };
  upcomingEvents: {
    main: string;
    why?: string; // optional if you don’t have a “why” for events
  };
}

export const collegeData: CollegeData = {
  basic: {
    name: "Samrat Ashok Technological Institute (SATI)",
    location: "Civil Lines, Vidisha, Madhya Pradesh",
    established: "1960",
    affiliation: "Rajiv Gandhi Proudyogiki Vishwavidyalaya (RGPV), Bhopal",
    type: "Government Aided, Autonomous Institution"
  },
  
  departments: {
    "computer science": {
      name: "Computer Science & Engineering (CSE)",
      programs: ["B.Tech CSE", "M.Tech CSE", "Ph.D"],
      faculty: "Dr. Kanak Saxena (Head of Department)",
      specializations: ["Software Engineering", "AI/ML", "Data Science", "Web Development", "Mobile App Development"],
      labs: ["Programming Lab", "Software Engineering Lab", "AI/ML Lab", "Database Lab", "Network Lab"]
    },
    "information technology": {
      name: "Information Technology (IT)",
      programs: ["B.Tech IT", "M.Tech IT"],
      faculty: "Dr. Shailendra Shrivastava (Head) - shailendrashrivastava@rediffmail.com, +91-9425150410",
      specializations: ["System Administration", "Network Security", "Database Management", "Web Technologies"],
      labs: ["IT Lab", "Network Lab", "Database Lab", "Web Development Lab"]
    },
    "mechanical": {
      name: "Mechanical Engineering",
      programs: ["B.Tech Mechanical", "M.Tech Mechanical", "Ph.D"],
      faculty: "Dr. Sanjay Katarey (Head) - sanjaykatarey@hotmail.com, +91-9826050049",
      specializations: ["Thermal Engineering", "Manufacturing", "Automobile", "Design Engineering", "Production"],
      labs: ["Manufacturing Lab", "Thermal Lab", "Fluid Mechanics Lab", "CAD/CAM Lab", "Workshop"]
    },
    "electrical": {
      name: "Electrical Engineering", 
      programs: ["B.Tech Electrical", "M.Tech Electrical", "Ph.D"],
      faculty: "Experienced faculty with industry expertise",
      specializations: ["Power Systems", "Control Systems", "Power Electronics", "Renewable Energy", "Electrical Machines"],
      labs: ["Power Electronics Lab", "Electrical Machines Lab", "Control Systems Lab", "Power Systems Lab"]
    },
    "civil": {
      name: "Civil Engineering",
      programs: ["B.Tech Civil", "M.Tech Civil", "Ph.D"],
      faculty: "Qualified faculty with research experience", 
      specializations: ["Structural Engineering", "Transportation", "Environmental", "Geotechnical", "Construction Management"],
      labs: ["Concrete Lab", "Soil Mechanics Lab", "Survey Lab", "Environmental Lab", "Highway Materials Lab"]
    },
    "electronics": {
      name: "Electronics & Communication Engineering",
      programs: ["B.Tech ECE", "M.Tech ECE"],
      faculty: "Experienced ECE faculty",
      specializations: ["VLSI Design", "Communication Systems", "Signal Processing", "Embedded Systems"],
      labs: ["Communication Lab", "VLSI Lab", "Signal Processing Lab", "Microprocessor Lab"]
    }
  },

  admissions: {
    eligibility: "JEE Main qualified candidates for B.Tech, GATE for M.Tech",
    process: "Online counseling through RGPV, MP BE counseling",
    seats: "Multiple branches with good intake capacity",
    fees: "₹75,000 - ₹95,000 per year (varies by course)",
    documents: ["JEE Main/GATE scorecard", "12th marksheet", "Category certificate (if applicable)", "Domicile certificate", "Transfer certificate"]
  },

  facilities: [
    "NAAC 'A' Grade accredited",
    "NBA accredited programs",
    "Central Library with extensive collection",
    "Modern computer labs with latest software", 
    "Well-equipped laboratories for all departments",
    "Separate hostels for boys and girls",
    "Sports facilities and gymnasium",
    "Cafeteria and mess facilities",
    "Medical facility on campus",
    "Transportation facility",
    "Wi-Fi enabled campus",
    "Active placement cell",
    "Research facilities",
    "Industry collaboration programs"
  ],

  contact: {
    address: "Samrat Ashok Technological Institute, Civil Lines, Vidisha - 464001, Madhya Pradesh",
    phone: "+91-7592-252100",
    email: "info@sati.ac.in",
    website: "www.satiengg.in"
  },
  hostels:  {
    main: "SATI has 3 boys’ hostels (325 seats) and 2 girls’ hostels (100 seats each), equipped with furniture, Wi-Fi, water purifiers, and solar water heating. Hostel fee is approximately ₹24,200 per year, and mess fee is around ₹20,000. The mess menu is student-driven and the food quality is moderate. The condition of boys’ hostels is slightly poorer compared to girls’ hostels. Registration is done through the SATI website.",
    why: "Hostels are designed to be safe and comfortable, meeting students’ daily needs."
  },
  campusLife: {
    main: "SATI offers a vibrant campus life with events like Samrat Utsav (a techno-cultural fest) and Satyarth-I (named after alumnus Kailash Satyarthi, Nobel Peace Prize 2014). Active clubs include Mirage (Photography), Udaan (Social Awareness), Flux (Innovation), SAE (Automotive), and Inspire (linked with IITs/NITs). Sports facilities include cricket, basketball, and volleyball courts.",
    why: "Campus life promotes holistic development, creativity, and leadership among students."
  },
  alumni: {
    main: "Notable alumni of SATI include Kailash Satyarthi (Nobel Peace Prize 2014), P.B. Sharma (former Vice-Chancellor, Delhi Technological University), and Padma Shri V.K. Chaturvedi (former Chairman, Nuclear Power Corporation of India). Alumni support placements and fund innovative ideas.",
    why: "Alumni reflect SATI’s legacy and contribute to the institute's growth."
  },
  upcomingEvents: {
    main: "SATI organizes annual events like Samrat Utsav (techno-cultural fest) and Satyarth-I (in honor of alumnus Kailash Satyarthi). These include technical competitions, cultural programs, and sports events. Exact dates for 2025 will be updated on the official SATI website."
  }

};
