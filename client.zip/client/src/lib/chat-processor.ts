import { collegeData, Department } from './college-data';

export function generateResponse(userMessage: string): string {
  const message = userMessage.toLowerCase();
  
  // Department-related queries
  if (message.includes('department') || message.includes('branch') || message.includes('course')) {
    if (message.includes('computer') || message.includes('cse') || message.includes('cs')) {
      return formatDepartmentInfo(collegeData.departments["computer science"]);
    } else if (message.includes('information technology') || message.includes('it')) {
      return formatDepartmentInfo(collegeData.departments["information technology"]);
    } else if (message.includes('mechanical')) {
      return formatDepartmentInfo(collegeData.departments["mechanical"]);
    } else if (message.includes('electrical')) {
      return formatDepartmentInfo(collegeData.departments["electrical"]);
    } else if (message.includes('civil')) {
      return formatDepartmentInfo(collegeData.departments["civil"]);
    } else if (message.includes('electronics') || message.includes('ece')) {
      return formatDepartmentInfo(collegeData.departments["electronics"]);
    } else {
      return `<strong>Departments at SATI:</strong><br><br>🔹 Computer Science & Engineering (CSE)<br>🔹 Information Technology (IT)<br>🔹 Mechanical Engineering<br>🔹 Electrical Engineering<br>🔹 Civil Engineering<br>🔹 Electronics & Communication Engineering (ECE)<br><br>Ask me about any specific department for detailed information!`;
    }
  }

  // Admission-related queries
  if (message.includes('admission') || message.includes('eligibility') || message.includes('fees') || message.includes('entrance')) {
    return `<strong>Admissions Information:</strong><br><br>📋 <strong>Eligibility:</strong> ${collegeData.admissions.eligibility}<br>🔄 <strong>Process:</strong> ${collegeData.admissions.process}<br>🎯 <strong>Total Seats:</strong> ${collegeData.admissions.seats}<br>💰 <strong>Fees:</strong> ${collegeData.admissions.fees}<br><br><strong>Required Documents:</strong><br>${collegeData.admissions.documents.map(doc => `• ${doc}`).join('<br>')}`;
  }

  // Faculty-related queries
  if (message.includes('faculty') || message.includes('teacher') || message.includes('professor') || message.includes('hod') || message.includes('head')) {
    return `<strong>Faculty Information:</strong><br><br>👨‍🏫 Our college has highly qualified and experienced faculty members:<br><br>🔹 <strong>CSE:</strong> Dr. Kanak Saxena (Head of Department)<br>🔹 <strong>IT:</strong> Dr. Shailendra Shrivastava (Head) - shailendrashrivastava@rediffmail.com, +91-9425150410<br>🔹 <strong>Mechanical:</strong> Dr. Sanjay Katarey (Head) - sanjaykatarey@hotmail.com, +91-9826050049<br>🔹 <strong>Electrical:</strong> Experienced faculty with industry expertise<br>🔹 <strong>Civil:</strong> Qualified faculty with research experience<br>🔹 <strong>ECE:</strong> Experienced ECE faculty<br><br>All faculty members hold advanced degrees and have industry/research experience.`;
  }

  // Facilities-related queries
  if (message.includes('facilities') || message.includes('infrastructure') || message.includes('lab') || message.includes('hostel')) {
    return `<strong>College Facilities:</strong><br><br>${collegeData.facilities.map(facility => `🏢 ${facility}`).join('<br>')}<br><br>We provide world-class infrastructure for holistic student development!`;
  }

  // Contact-related queries
  if (message.includes('contact') || message.includes('address') || message.includes('phone') || message.includes('location')) {
    return `<strong>Contact Information:</strong><br><br>📍 <strong>Address:</strong> ${collegeData.contact.address}<br>📞 <strong>Phone:</strong> ${collegeData.contact.phone}<br>📧 <strong>Email:</strong> ${collegeData.contact.email}<br>🌐 <strong>Website:</strong> ${collegeData.contact.website}`;
  }

  // Basic college info
  if (message.includes('about') || message.includes('college') || message.includes('sati') || message.includes('information')) {
    return `<strong>About SATI College:</strong><br><br>🏛️ <strong>Name:</strong> ${collegeData.basic.name}<br>📍 <strong>Location:</strong> ${collegeData.basic.location}<br>📅 <strong>Established:</strong> ${collegeData.basic.established}<br>🎓 <strong>Affiliation:</strong> ${collegeData.basic.affiliation}<br>🏛️ <strong>Type:</strong> ${collegeData.basic.type}<br><br>SATI is a premier government engineering institution providing quality technical education!`;
  }
// ...previous blocks...

if (message.includes('upcoming') || message.includes('event')) {
  return `<strong>Upcoming Events:</strong><br><br>📅 ${collegeData.upcomingEvents.main}<br><br>✨ ${collegeData.upcomingEvents.why}`;
}

if (message.includes('campus life') || message.includes('college life')) {
  return `<strong>Campus Life at SATI:</strong><br><br>🎉 ${collegeData.campusLife.main}<br><br>💬 ${collegeData.campusLife.why}`;
}

if (message.includes('hostel') || message.includes('stay')) {
  return `<strong>Hostel Information:</strong><br><br>🏨 ${collegeData.hostels.main}<br><br>💡 ${collegeData.hostels.why}`;
}

  // Greeting responses
  if (message.includes('hello') || message.includes('hi') || message.includes('namaste') || message.includes('hii')) {
    return `👋 Hello! Welcome to SATI College! 😄 Kya information chahiye aapko?<br><br>I can help you with:<br>🔹 College information<br>🔹 Departments and courses<br>🔹 Faculty details<br>🔹 Admissions process<br>🔹 Facilities<br><br>Ask me anything about SATI!`;
  }

  // Default response
  return `I'd be happy to help you with information about SATI College! You can ask me about:<br><br>🔹 Departments and courses<br>🔹 Admissions and eligibility<br>🔹 Faculty information<br>🔹 College facilities<br>🔹 Contact details<br><br>What specific information would you like to know?`;
}

function formatDepartmentInfo(dept: Department): string {
  return `<strong>${dept.name} Department</strong><br><br>📚 <strong>Programs:</strong><br>${dept.programs.map(p => `• ${p}`).join('<br>')}<br><br>👨‍🏫 <strong>Faculty:</strong> ${dept.faculty}<br><br>🎯 <strong>Specializations:</strong><br>${dept.specializations.map(s => `• ${s}`).join('<br>')}<br><br>🔬 <strong>Laboratories:</strong><br>${dept.labs.map(l => `• ${l}`).join('<br>')}`;
}

export function getQuickResponses() {
  return {
    departments: () => generateResponse("departments"),
    admissions: () => generateResponse("admission"),
    facilities: () => generateResponse("facilities"),
    faculty: () => generateResponse("faculty"),
    contact: () => generateResponse("contact"),
    hostel: () => generateResponse("hostel"),
    campusLife: () => generateResponse("campus life"),
    events: () => generateResponse("events")
  };
}

