import { useState } from "react";
import { ChatHeader } from "@/components/ui/chat-header";
import { QuickActions } from "@/components/ui/quick-actions";
import { ChatMessages, Message } from "@/components/ui/chat-messages";
import { MessageInput } from "@/components/ui/message-input";
import { generateResponse, getQuickResponses } from "@/lib/chat-processor";

export default function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);

  const addMessage = (content: string, sender: 'user' | 'bot') => {
    const newMessage: Message = {
      id: Date.now().toString(),
      content,
      sender,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const handleSendMessage = async (userMessage: string) => {
    // Add user message
    addMessage(userMessage, 'user');
    
    // Show typing indicator
    setIsTyping(true);
    
    // Simulate bot response delay
    setTimeout(() => {
      setIsTyping(false);
      const response = generateResponse(userMessage);
      addMessage(response, 'bot');
    }, Math.random() * 1000 + 500); // Random delay between 500-1500ms
  };

  const handleQuickAction = (action: string) => {
    const quickResponses = getQuickResponses();
    
    const userMessages: Record<string, string> = {
      departments: "Tell me about the departments available at SATI",
      admissions: "What is the admission process and eligibility?",
      facilities: "What facilities are available at the college?",
      faculty: "Tell me about the faculty members",
      contact: "How can I contact the college?"
    };

    const userMessage = userMessages[action];
    if (userMessage) {
      addMessage(userMessage, 'user');
      
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        const response = (quickResponses as any)[action]();
        addMessage(response, 'bot');
      }, 800);
    }
  };

  return (
    <div className="min-h-screen flex flex-col max-w-4xl mx-auto bg-white shadow-xl">
      <ChatHeader />
      <QuickActions onQuickAction={handleQuickAction} />
      <ChatMessages messages={messages} isTyping={isTyping} />
      <MessageInput onSendMessage={handleSendMessage} disabled={isTyping} />
    </div>
  );
}
